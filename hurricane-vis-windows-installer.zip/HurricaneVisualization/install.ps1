# Hurricane Visualization Dashboard - Windows Installer
# Run this script in PowerShell as Administrator

Write-Host "======================================================" -ForegroundColor Cyan
Write-Host "   Hurricane Visualization Dashboard - Installer    " -ForegroundColor Cyan
Write-Host "======================================================" -ForegroundColor Cyan
Write-Host ""

# Check if running as Administrator
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "⚠️  Please run PowerShell as Administrator" -ForegroundColor Yellow
    Write-Host "   Right-click PowerShell → 'Run as Administrator'" -ForegroundColor Yellow
    pause
    exit 1
}

Write-Host "📋 Checking prerequisites..." -ForegroundColor Blue

# Check Docker Desktop
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    Write-Host "⚠️  Docker Desktop is not installed" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Please install Docker Desktop for Windows:" -ForegroundColor Yellow
    Write-Host "  1. Visit: https://www.docker.com/products/docker-desktop/" -ForegroundColor White
    Write-Host "  2. Download Docker Desktop for Windows" -ForegroundColor White
    Write-Host "  3. Install and restart your computer" -ForegroundColor White
    Write-Host "  4. Run this installer again" -ForegroundColor White
    Write-Host ""
    
    $download = Read-Host "Would you like to open the download page now? (y/N)"
    if ($download -eq "y" -or $download -eq "Y") {
        Start-Process "https://www.docker.com/products/docker-desktop/"
    }
    pause
    exit 1
} else {
    Write-Host "✅ Docker Desktop is installed" -ForegroundColor Green
}

# Check Python
if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    Write-Host "⚠️  Python is not installed" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Please install Python 3.8 or higher:" -ForegroundColor Yellow
    Write-Host "  1. Visit: https://www.python.org/downloads/" -ForegroundColor White
    Write-Host "  2. Download Python 3.12 for Windows" -ForegroundColor White
    Write-Host "  3. Install (check 'Add Python to PATH')" -ForegroundColor White
    Write-Host "  4. Run this installer again" -ForegroundColor White
    Write-Host ""
    
    $download = Read-Host "Would you like to open the download page now? (y/N)"
    if ($download -eq "y" -or $download -eq "Y") {
        Start-Process "https://www.python.org/downloads/"
    }
    pause
    exit 1
} else {
    Write-Host "✅ Python is installed" -ForegroundColor Green
}

# Installation directory
$installDir = "$env:LOCALAPPDATA\HurricaneVisualization"
Write-Host ""
Write-Host "📁 Installation directory: $installDir" -ForegroundColor Blue

# Create installation directory
if (Test-Path $installDir) {
    $overwrite = Read-Host "Installation directory exists. Overwrite? (y/N)"
    if ($overwrite -ne "y" -and $overwrite -ne "Y") {
        Write-Host "Installation cancelled." -ForegroundColor Yellow
        pause
        exit 0
    }
    Remove-Item -Recurse -Force $installDir
}

New-Item -ItemType Directory -Force -Path $installDir | Out-Null

# Copy files
Write-Host "📦 Installing application files..." -ForegroundColor Blue
Copy-Item -Recurse -Force "$PSScriptRoot\*" -Destination $installDir -Exclude "install.ps1","install.bat"

# Create desktop shortcut
Write-Host "🖥️  Creating desktop shortcut..." -ForegroundColor Blue
$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("$env:USERPROFILE\Desktop\Hurricane Visualization.lnk")
$Shortcut.TargetPath = "powershell.exe"
$Shortcut.Arguments = "-ExecutionPolicy Bypass -File `"$installDir\run-windows.ps1`""
$Shortcut.WorkingDirectory = $installDir
$Shortcut.IconLocation = "shell32.dll,13"
$Shortcut.Description = "Gulf Coast Hurricane Visualization Dashboard"
$Shortcut.Save()

# Create start menu shortcut
$startMenuPath = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs"
New-Item -ItemType Directory -Force -Path $startMenuPath | Out-Null
$Shortcut = $WshShell.CreateShortcut("$startMenuPath\Hurricane Visualization.lnk")
$Shortcut.TargetPath = "powershell.exe"
$Shortcut.Arguments = "-ExecutionPolicy Bypass -File `"$installDir\run-windows.ps1`""
$Shortcut.WorkingDirectory = $installDir
$Shortcut.IconLocation = "shell32.dll,13"
$Shortcut.Description = "Gulf Coast Hurricane Visualization Dashboard"
$Shortcut.Save()

Write-Host ""
Write-Host "✅ Installation complete!" -ForegroundColor Green
Write-Host ""
Write-Host "======================================================" -ForegroundColor Cyan
Write-Host "                 Installation Summary                 " -ForegroundColor Cyan
Write-Host "======================================================" -ForegroundColor Cyan
Write-Host "📍 Location: $installDir" -ForegroundColor Blue
Write-Host "🖥️  Desktop Shortcut: Created" -ForegroundColor Blue
Write-Host "📋 Start Menu: Created" -ForegroundColor Blue
Write-Host ""
Write-Host "📖 To launch:" -ForegroundColor Yellow
Write-Host "   • Double-click the desktop shortcut" -ForegroundColor White
Write-Host "   • Or search 'Hurricane Visualization' in Start Menu" -ForegroundColor White
Write-Host ""

$launch = Read-Host "Would you like to launch the application now? (y/N)"
if ($launch -eq "y" -or $launch -eq "Y") {
    Write-Host "🚀 Launching Hurricane Visualization Dashboard..." -ForegroundColor Green
    Start-Process powershell -ArgumentList "-ExecutionPolicy Bypass -File `"$installDir\run-windows.ps1`""
}

Write-Host ""
Write-Host "Thank you for installing Hurricane Visualization Dashboard!" -ForegroundColor Blue
pause
