# Hurricane Visualization Dashboard - Windows Launcher

Write-Host "🌀 Hurricane Visualization Dashboard" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

Set-Location $PSScriptRoot

# Check if Docker Desktop is running
$dockerRunning = docker ps 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Host "⚠️  Docker Desktop is not running" -ForegroundColor Yellow
    Write-Host "   Please start Docker Desktop and try again" -ForegroundColor Yellow
    Write-Host ""
    
    $startDocker = Read-Host "Would you like to start Docker Desktop now? (y/N)"
    if ($startDocker -eq "y" -or $startDocker -eq "Y") {
        Start-Process "C:\Program Files\Docker\Docker\Docker Desktop.exe"
        Write-Host "Waiting for Docker to start..." -ForegroundColor Yellow
        Start-Sleep -Seconds 10
    } else {
        pause
        exit 1
    }
}

# Check mode preference
Write-Host "Select runtime mode:" -ForegroundColor Blue
Write-Host "  1. Docker (Recommended - Containerized)" -ForegroundColor White
Write-Host "  2. Local Python (Direct execution)" -ForegroundColor White
Write-Host ""
$mode = Read-Host "Enter choice (1 or 2)"

if ($mode -eq "1") {
    Write-Host ""
    Write-Host "🐳 Launching with Docker..." -ForegroundColor Blue
    Write-Host ""
    
    # Build and run with Docker Compose
    docker-compose build
    docker-compose up
    
} else {
    Write-Host ""
    Write-Host "🐍 Launching with Python..." -ForegroundColor Blue
    Write-Host ""
    
    # Create virtual environment if it doesn't exist
    if (-not (Test-Path ".venv")) {
        Write-Host "Creating Python virtual environment..." -ForegroundColor Yellow
        python -m venv .venv
    }
    
    # Activate virtual environment
    .\.venv\Scripts\Activate.ps1
    
    # Install dependencies
    if (-not (Test-Path ".venv\.dependencies_installed")) {
        Write-Host "Installing dependencies (this may take a few minutes)..." -ForegroundColor Yellow
        python -m pip install --upgrade pip
        pip install -r requirements.txt
        New-Item -ItemType File -Path ".venv\.dependencies_installed" | Out-Null
    }
    
    # Launch application
    python launch_with_loading.py
}

Write-Host ""
Write-Host "✅ Application closed" -ForegroundColor Green
pause
