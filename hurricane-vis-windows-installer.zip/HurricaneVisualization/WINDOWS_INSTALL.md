# Hurricane Visualization Dashboard - Windows Installation

## Prerequisites

1. **Docker Desktop** (Recommended)
   - Download: https://www.docker.com/products/docker-desktop/
   - Install and restart your computer
   - Ensure Docker Desktop is running before launching the app

2. **Python 3.8+** (Alternative to Docker)
   - Download: https://www.python.org/downloads/
   - During installation, check "Add Python to PATH"

## Installation

### Option 1: Easy Install (Recommended)
1. Double-click `install.bat`
2. Follow the prompts
3. Launch from desktop shortcut or Start Menu

### Option 2: PowerShell Install
1. Right-click PowerShell → "Run as Administrator"
2. Navigate to this folder
3. Run: `.\install.ps1`

## Running the Application

After installation:
- **Desktop**: Double-click "Hurricane Visualization" shortcut
- **Start Menu**: Search for "Hurricane Visualization"
- **Manual**: Run `run.bat` in installation folder

## Troubleshooting

**"Docker is not running"**
- Start Docker Desktop before launching the app
- Wait ~30 seconds for Docker to fully start

**"Python not found"**
- Install Python from https://www.python.org/downloads/
- Ensure "Add Python to PATH" was checked during installation
- Restart PowerShell after installation

**"Access Denied"**
- Run PowerShell as Administrator
- Right-click PowerShell → "Run as Administrator"

## Uninstallation

1. Delete desktop and Start Menu shortcuts
2. Delete installation folder:
   - Location: `%LOCALAPPDATA%\HurricaneVisualization`
3. (Optional) Uninstall Docker Desktop from Windows Settings

## Support

GitHub: https://github.com/SauceSlinger/gulfCoastHurricaneVis
Issues: https://github.com/SauceSlinger/gulfCoastHurricaneVis/issues
