# Hurricane Visualization Dashboard - macOS Installation

## Prerequisites

1. **Docker Desktop for Mac**
   - Download: https://www.docker.com/products/docker-desktop/
   - Choose: Apple Silicon (M1/M2/M3) or Intel
   - Install by dragging to Applications folder
   - Open Docker Desktop and complete initial setup

2. **Python 3.8+** (Usually pre-installed on macOS)
   - Check: `python3 --version` in Terminal
   - If needed, download from: https://www.python.org/downloads/macos/

## Installation

### Option 1: Graphical Install
1. Extract the downloaded .zip file
2. Open the extracted folder
3. Double-click `install.sh`
4. Follow the prompts

### Option 2: Terminal Install
1. Extract the .zip file
2. Open Terminal
3. Navigate to the extracted folder:
   ```bash
   cd ~/Downloads/HurricaneVisualization
   ```
4. Run the installer:
   ```bash
   ./install.sh
   ```

## Running the Application

After installation:
- **Desktop**: Double-click "Hurricane Visualization" alias on Desktop
- **Applications**: Navigate to ~/Applications/HurricaneVisualization/
- **Manual**: Run `Hurricane Visualization.command`

## Troubleshooting

### "Docker is not running"
- Make sure Docker Desktop app is running
- Look for Docker icon in menu bar
- Wait ~30 seconds after starting Docker Desktop

### "Permission denied"
```bash
chmod +x install.sh
./install.sh
```

### "Python3 not found"
- macOS 10.15+ includes Python 3
- Or install from: https://www.python.org/downloads/macos/

### XQuartz (if GUI doesn't appear)
Some systems may need XQuartz for X11 display:
1. Install XQuartz: https://www.xquartz.org/
2. Log out and back in
3. Run the application again

## Uninstallation

1. Delete desktop alias: `~/Desktop/Hurricane Visualization`
2. Delete application folder: `~/Applications/HurricaneVisualization`
3. (Optional) Uninstall Docker Desktop from Applications

## Apple Silicon (M1/M2/M3) Notes

- Use Docker Desktop for Apple Silicon
- Python native ARM support available
- Performance is excellent on Apple Silicon

## Support

- GitHub: https://github.com/SauceSlinger/gulfCoastHurricaneVis
- Issues: https://github.com/SauceSlinger/gulfCoastHurricaneVis/issues
