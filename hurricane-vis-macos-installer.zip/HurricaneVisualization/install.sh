#!/bin/bash
# Hurricane Visualization Dashboard - macOS Installer

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}"
cat << "BANNER"
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║      🌀 Gulf Coast Hurricane Visualization Dashboard 🌀      ║
║                                                               ║
║                    macOS Installer                            ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
BANNER
echo -e "${NC}"

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

echo -e "${BLUE}📋 Checking prerequisites...${NC}"

# Check Docker Desktop
if ! command_exists docker; then
    echo -e "${YELLOW}⚠️  Docker Desktop is not installed${NC}"
    echo ""
    echo "Docker Desktop is required for this application."
    echo ""
    echo "Please install Docker Desktop for Mac:"
    echo "  1. Visit: https://www.docker.com/products/docker-desktop/"
    echo "  2. Download Docker Desktop for Mac (Apple Silicon or Intel)"
    echo "  3. Install by dragging to Applications folder"
    echo "  4. Open Docker Desktop and complete setup"
    echo "  5. Run this installer again"
    echo ""
    
    read -p "$(echo -e ${YELLOW}Would you like to open the download page now? [y/N]: ${NC})" -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        open "https://www.docker.com/products/docker-desktop/"
    fi
    exit 1
else
    echo -e "${GREEN}✅ Docker Desktop is installed${NC}"
    
    # Check if Docker is running
    if ! docker ps &> /dev/null; then
        echo -e "${YELLOW}⚠️  Docker Desktop is not running${NC}"
        echo -e "${BLUE}Starting Docker Desktop...${NC}"
        open -a Docker
        echo "Waiting for Docker to start (this may take 30-60 seconds)..."
        
        # Wait for Docker to be ready
        for i in {1..30}; do
            if docker ps &> /dev/null; then
                echo -e "${GREEN}✅ Docker is now running${NC}"
                break
            fi
            sleep 2
            echo -n "."
        done
        echo ""
    fi
fi

# Check Python 3
if ! command_exists python3; then
    echo -e "${YELLOW}⚠️  Python 3 is not installed${NC}"
    echo ""
    echo "Python 3 is required for this application."
    echo ""
    echo "Please install Python 3:"
    echo "  1. Visit: https://www.python.org/downloads/macos/"
    echo "  2. Download Python 3.12 for macOS"
    echo "  3. Install and run this installer again"
    echo ""
    
    read -p "$(echo -e ${YELLOW}Would you like to open the download page now? [y/N]: ${NC})" -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        open "https://www.python.org/downloads/macos/"
    fi
    exit 1
else
    echo -e "${GREEN}✅ Python 3 is installed${NC}"
fi

# Installation directory
INSTALL_DIR="$HOME/Applications/HurricaneVisualization"

echo ""
echo -e "${BLUE}📁 Installation directory: $INSTALL_DIR${NC}"

# Create installation directory
if [ -d "$INSTALL_DIR" ]; then
    read -p "$(echo -e ${YELLOW}Installation directory exists. Overwrite? [y/N]: ${NC})" -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Installation cancelled."
        exit 0
    fi
    rm -rf "$INSTALL_DIR"
fi

mkdir -p "$INSTALL_DIR"

# Copy files
echo -e "${BLUE}📦 Installing application files...${NC}"
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cp -R "$SCRIPT_DIR"/* "$INSTALL_DIR/"
rm -f "$INSTALL_DIR/install.sh"

# Make scripts executable
chmod +x "$INSTALL_DIR"/*.sh 2>/dev/null || true
chmod +x "$INSTALL_DIR"/*.py 2>/dev/null || true

# Create application wrapper
echo -e "${BLUE}🖥️  Creating application launcher...${NC}"

cat > "$INSTALL_DIR/Hurricane Visualization.command" << 'LAUNCHER_EOF'
#!/bin/bash
cd "$(dirname "$0")"
./run-macos.sh
LAUNCHER_EOF
chmod +x "$INSTALL_DIR/Hurricane Visualization.command"

# Create desktop shortcut (alias)
if [ -d "$HOME/Desktop" ]; then
    ln -sf "$INSTALL_DIR/Hurricane Visualization.command" "$HOME/Desktop/Hurricane Visualization"
fi

echo ""
echo -e "${GREEN}✅ Installation complete!${NC}"
echo ""
echo -e "${CYAN}╔═══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║                     Installation Summary                     ║${NC}"
echo -e "${CYAN}╔═══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}📍 Location:${NC} $INSTALL_DIR"
echo -e "${BLUE}🖥️  Desktop Alias:${NC} Created"
echo ""
echo -e "${YELLOW}📖 To launch:${NC}"
echo -e "   • Double-click 'Hurricane Visualization' on Desktop"
echo -e "   • Or open: $INSTALL_DIR/Hurricane Visualization.command"
echo ""
echo -e "${CYAN}╚═══════════════════════════════════════════════════════════════╝${NC}"
echo ""

read -p "$(echo -e ${YELLOW}Would you like to launch the application now? [y/N]: ${NC})" -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo -e "${GREEN}🚀 Launching Hurricane Visualization Dashboard...${NC}"
    cd "$INSTALL_DIR"
    ./run-macos.sh &
    echo -e "${GREEN}✅ Application launched!${NC}"
fi

echo -e "${BLUE}Thank you for installing Hurricane Visualization Dashboard!${NC}"
