#!/bin/bash
# Hurricane Visualization Dashboard - macOS Launcher

echo "🌀 Hurricane Visualization Dashboard"
echo "========================================"
echo ""

cd "$(dirname "$0")"

# Check if Docker is running
if ! docker ps &> /dev/null; then
    echo "⚠️  Docker Desktop is not running"
    echo "   Starting Docker Desktop..."
    open -a Docker
    echo "   Waiting for Docker to start..."
    
    for i in {1..30}; do
        if docker ps &> /dev/null; then
            echo "✅ Docker is running"
            break
        fi
        sleep 2
    done
fi

# Ask for runtime mode
echo "Select runtime mode:"
echo "  1. Docker (Recommended)"
echo "  2. Local Python"
echo ""
read -p "Enter choice (1 or 2): " mode

if [ "$mode" = "1" ]; then
    echo ""
    echo "🐳 Launching with Docker..."
    echo ""
    
    # Build and run with Docker Compose
    docker-compose build
    docker-compose up
    
else
    echo ""
    echo "🐍 Launching with Python..."
    echo ""
    
    # Create virtual environment if it doesn't exist
    if [ ! -d ".venv" ]; then
        echo "Creating Python virtual environment..."
        python3 -m venv .venv
    fi
    
    # Activate virtual environment
    source .venv/bin/activate
    
    # Install dependencies
    if [ ! -f ".venv/.dependencies_installed" ]; then
        echo "Installing dependencies (this may take a few minutes)..."
        pip install --upgrade pip
        pip install -r requirements.txt
        touch .venv/.dependencies_installed
    fi
    
    # Launch application
    python3 launch_with_loading.py
fi

echo ""
echo "✅ Application closed"
